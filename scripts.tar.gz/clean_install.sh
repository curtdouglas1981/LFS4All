#!/bin/sh

rm *.sh
rm packages.txt
