#!/bin/sh

systemctl enable NetworkManager
