#!/bin/sh

rm *.sh
rm packages.txt
rm scripts.tar.gz
